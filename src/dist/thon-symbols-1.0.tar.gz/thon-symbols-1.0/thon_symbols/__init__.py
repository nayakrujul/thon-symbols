from thon_symbols.main import run
